<?php
  include("../model/Carro.php");
  $carro1 = new Carro();

  $KmAtual = $_POST["KmAtual"];
  $valorAbastecimento =$_POST["valorAbastecimento"];
  $QTDabastecimento = $_POST["QTDabastecimento"];
  $KmLitro = $_POST["KmLitro"];

  $inserir = $carro1->cadastrar($KmAtual, $valorAbastecimento, $QTDabastecimento, $KmLitro);
  if ($inserir==1){
    header('location: ../view/formulario.php?mensagem=sucesso');
  }else{
    header('location: ../view/formulario.php?mensagem=erro');
  }

?>
