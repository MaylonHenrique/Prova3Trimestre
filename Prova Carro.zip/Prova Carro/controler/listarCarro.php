<?php
  include("../model/Carro.php");
  $listarCarro = new Carro();
  $retornoDados = $listarCarro->listar();

  echo "Foram encontrados " . count($retornoDados) . " registros.";//verifica quantos registros tem no vetor
  if (count($retornoDados) > 0){
    ?>
    <table border=1>
      <tr>
        <td>KmAtual</td>
        <td>valorAbastecimento</td>
        <td>QTDabastecimento</td>
        <td>KmLitro</td>

      </tr>
      <?php
      foreach ($retornoDados as $key => $value) {
        echo "<tr><td>" . $value["KmAtual"];
        echo "</td><td>" . $value["valorAbastecimento"];
        echo "</td><td>" . $value["QTDabastecimento"];
        echo "</td><td>" . $value["KmLitro"];
        echo "</td></tr>";
      }
      ?>
    </table>
    <?php
  }

?>
