<?php
class Carro{
  private $KmAtual, $valorAbastecimento, $QTDabastecimento, $KmLitro;

public function setKmAtual($KmAtual){
  $this->KmAtual=$KmAtual;
}

public function getKmAtual(){
  return $this->KmAtual;
}

  public function setvalorAbastecimento($valorAbastecimento){
    $this->valorAbastecimento = $valorAbastecimento;
  }
  public function setQTDabastecimento($QTDabastecimento){
    $this->QTDabastecimento = $QTDabastecimento;
  }
  public function getvalorAbastecimento(){
    return $this->valorAbastecimento;
  }
  public function getQTDabastecimento(){
    return $this->QTDabastecimento;
  }
  public function setKmLitro($KmLitro){
    $this->KmLitro = $KmLitro;
  }
  public function getKmLitro(){
    return $this->KmLitro;
  }

  public function cadastrar($KmAtual, $valorAbastecimento, $QTDabastecimento, $KmLitro){
    $this->setKmAtual($KmAtual);
    $this->setvalorAbastecimento($valorAbastecimento);
    $this->setQTDabastecimento($QTDabastecimento);
    $this->setKmLitro($KmLitro);
    //query de consulta para inclusão
    echo $sqlInsert = "insert into Carro
    (KmAtual, valorAbastecimento, QTDabastecimento, KmLitro)
    values
    ('{$this->getKmAtual()}','{$this->getvalorAbastecimento()}','{$this->getQTDabastecimento()}','{$this->getKmLitro()}')";
    //executar a query
    include("Conexao.php");
    $conectar = new Conexao();
    if($retornoInsert = $conectar->getConectar()->query($sqlInsert)){
      return 1;//retorna 1 caso seja gravado
    }else {
      return 0;//retorna 0 caso não seja gravado
    }
  }
  public function listar(){
    $lista = "select * from Carro";
    include ("Conexao.php");
    $objetoListar = new Conexao();
    $retornoBanco = $objetoListar->getConectar()->query($lista);
    $dados = array();
    while($temp = $retornoBanco->fetch_array()) {
      $dados[]=$temp;
    }
    return $dados;

  }
}
?>
