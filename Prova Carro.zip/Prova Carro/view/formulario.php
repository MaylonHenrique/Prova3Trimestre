<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    if(isset($_GET["mensagem"]) & !empty($_GET["mensagem"])){
      if($_GET["mensagem"]=="sucesso"){
        echo "Dados gravados com sucesso!!!";
      }elseif ($_GET["mensagem"]=="erro"){
        echo "Erro ao gravar os dados!!!";
      }
    }
     ?>
    <form action="../controler/controle.php" method="post">
      <br><label>KmAtual: </label>
      <input type="text" name="KmAtual" value=""><br>
      <br><label>valorAbastecimento: </label>
      <input type="text" name="valorAbastecimento" value=""><br>
      <br><label>QTDabastecimento: </label>
      <input type="text" name="QTDabastecimento" value=""><br>
      <br><label>KmLitro: </label>
      <input type="text" name="KmLitro" value=""><br>
      <br><input type="submit" name="" value="Enviar"><br>
    </form>
  </body>
</html>
