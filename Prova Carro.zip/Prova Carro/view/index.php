<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <ul>
      <li><a href="formulario.php">Cadastro</a></li>
      <li><a href="../controler/listarCarro.php">Listar</a></li>
    </ul>
  </body>
</html>
